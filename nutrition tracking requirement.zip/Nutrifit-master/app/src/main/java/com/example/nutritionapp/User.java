package com.example.nutritionapp;

public class User {
    public String name,email,mobile;

    public User(){

    }
    public User(String name,String email, String mobile){
        this.name=name;
        this.email=email;
        this.mobile=mobile;


    }
}
